#ifndef RESOURCEMANAGER_H
#define RESOURCEMANAGER_H

#include <iostream>
#include <map>
#include <Assets.h>
#include <vector3d.h>

class ResourceManager{

public:
    ResourceManager();
    static void LoadResources();
};

#endif