#ifndef OPTIONSMENU_H
#define OPTIONSMENU_H

#include <GUIEngine/Menu.h>

class OptionsMenu : public Menu{
    public:
    OptionsMenu(MenuType);
    ~OptionsMenu();

};

#endif