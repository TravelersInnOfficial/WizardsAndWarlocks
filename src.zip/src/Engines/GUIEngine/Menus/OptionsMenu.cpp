#include "OptionsMenu.h"

OptionsMenu::OptionsMenu(MenuType type) : Menu(type){}
OptionsMenu::~OptionsMenu(){}