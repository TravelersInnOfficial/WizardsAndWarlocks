#include "CharacterSound.h"

/******************************************************
 *  Default constructor
 ******************************************************/
CharacterSound::CharacterSound() {}

/******************************************************
 *  Destructor
 ******************************************************/
CharacterSound::~CharacterSound() {}