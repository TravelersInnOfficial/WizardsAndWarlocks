#include "CommonSoundEvent.h"

/******************************************************
 *  Default constructor 
 ******************************************************/
CommonSoundEvent::CommonSoundEvent() {}

/******************************************************
 *  Destructor
******************************************************/
CommonSoundEvent::~CommonSoundEvent() {}
