#ifndef NPCTYPES_H
#define NPCTYPES_H

enum NPCType {
	NPC_SELLER		= 0x00,
	NPC_SELECTOR	= 0x01,
	NPC_POWERUP		= 0x02,
};

#endif