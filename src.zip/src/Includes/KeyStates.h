#ifndef KEYSTATES_H
#define KEYSTATES_H

enum keyStatesENUM {
	UP,				// Key sin pulsar
	DOWN,			// Key pulsandose
	PRESSED,		// Key pulsada durante el frame
	RELEASED		// Key levantada durante el frame
};

#endif