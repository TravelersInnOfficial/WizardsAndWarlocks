#ifndef AREACODES_H
#define AREACODES_H

enum AreaEnum{
	AREA_ICE,
	AREA_POISON
};

#endif